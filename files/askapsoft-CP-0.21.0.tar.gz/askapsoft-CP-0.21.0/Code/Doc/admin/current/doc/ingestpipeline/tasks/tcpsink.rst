TCP Connection Sink
===================
