Operations utilities
=====================

**Contents:**

.. toctree::
   :maxdepth: 1

   extractdata.rst
   genoffsets.rst
