Channel Flagging Task
=====================
