Phase Tracking Task
===================
