Sky Model Service
=================

.. note:: TODO: Write this documentation

