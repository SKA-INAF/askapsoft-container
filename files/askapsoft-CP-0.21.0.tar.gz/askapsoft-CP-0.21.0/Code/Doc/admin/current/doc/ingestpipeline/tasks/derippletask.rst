De-Ripple Task
==============
