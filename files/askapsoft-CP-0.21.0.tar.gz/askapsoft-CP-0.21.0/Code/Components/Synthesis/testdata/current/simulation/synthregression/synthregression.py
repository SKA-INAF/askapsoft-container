print "wtermtest: WProject and WStack gridders"
import wtermtest
print "pbcorrtest: single field with mosaicing gridders (primary beam correction)"
import pbcorrtest
print "noisetest: testing that the noise in the output image is as expected"
import noisetest
print "facetingtest: test of faceted imaging with spherical function gridder"
import facetingtest
print "calibratortest: test of ccalibrator"
import calibratortest
print "leakagecalibtest: test of polarisation leakage calibration"
import leakagecalibtest
print "1934-638: test source position and flux on real ATCA data"
import test1934
