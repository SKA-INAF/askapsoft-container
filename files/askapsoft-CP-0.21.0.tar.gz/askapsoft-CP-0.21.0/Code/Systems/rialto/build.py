import os, shutil
from askapdev.rbuild.builders import Builder
import askapdev.rbuild.utils as utils

builder = Builder(".")
builder.build()
