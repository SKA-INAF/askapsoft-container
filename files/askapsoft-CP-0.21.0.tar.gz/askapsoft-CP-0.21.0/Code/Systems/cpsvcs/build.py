from askapdev.rbuild.builders import Data as Builder

builder = Builder("scripts")
builder.build()
