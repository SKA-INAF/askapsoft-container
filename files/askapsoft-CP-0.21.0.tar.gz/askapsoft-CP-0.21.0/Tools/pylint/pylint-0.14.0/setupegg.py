from setuptools import setup
execfile('setup.py')
