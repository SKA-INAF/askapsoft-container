from askapdev.rbuild.builders import Setuptools as Builder

builder = Builder('.')
builder.build()
