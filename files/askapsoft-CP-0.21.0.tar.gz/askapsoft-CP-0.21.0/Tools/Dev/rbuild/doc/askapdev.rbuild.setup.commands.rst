commands Package
================

:mod:`commands` Package
-----------------------

.. automodule:: askapdev.rbuild.setup.commands
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`clean` Module
-------------------

.. automodule:: askapdev.rbuild.setup.commands.clean
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`doc` Module
-----------------

.. automodule:: askapdev.rbuild.setup.commands.doc
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`pylint` Module
--------------------

.. automodule:: askapdev.rbuild.setup.commands.pylint
    :members:
    :undoc-members:
    :show-inheritance:

