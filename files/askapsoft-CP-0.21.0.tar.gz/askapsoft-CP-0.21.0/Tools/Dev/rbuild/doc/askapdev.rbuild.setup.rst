setup Package
=============

:mod:`setup` Package
--------------------

.. automodule:: askapdev.rbuild.setup
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`setup` Module
-------------------

.. automodule:: askapdev.rbuild.setup.setup
    :members:
    :undoc-members:
    :show-inheritance:

Subpackages
-----------

.. toctree::

    askapdev.rbuild.setup.commands

