exceptions Module
=================

:mod:`exceptions` Module
------------------------

.. automodule:: askapdev.rbuild.exceptions
    :members:
    :undoc-members:
    :show-inheritance:
